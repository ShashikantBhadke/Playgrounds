import UIKit

final class Convert {
    
    func convertToASCII(char: Character)->Int {
        return Int(char.unicodeScalars.first?.value ?? 0)
    }
    
    func convertToChar(ascii: Int)->String {
        return String(UnicodeScalar(UInt8(ascii)))
    }
    
    func convertToNext(strMax: String, value: String)->(isSuccess: Bool, nextVal: String) {
        let ascii = self.convertToASCII(char: Character(value))
        if ((ascii + 1) <= self.convertToASCII(char: Character(strMax))) {
            return (true, self.convertToChar(ascii: ascii + 1))
        } else {
            return (false, value)
        }
    }
    
    func getLastString(strMax: String, strMin: String, value: String)->(isSuccess: Bool, nextVal: String) {
        var arrStr = Array(value)
        arrStr = arrStr.reversed()
        for i in 0..<arrStr.count {
            let response = self.convertToNext(strMax: strMax, value: String(arrStr[i]))
            if response.isSuccess {
                var newArr = arrStr
                for j in 0..<i {
                    if String(newArr[j]) == strMax {
                        newArr[j] = Character(strMin)
                    }
                }
                newArr[i] = Character(response.nextVal)
                return (true, String(newArr.reversed()))
            }
        }
        return (false, "")
    }
} //class

let strMin = "A"
let strMax = "Z"
var initial = "AAAA"
var arrPossibilities = [String]()
let converter = Convert()
var time1 = Date()
arrPossibilities.append(initial)

repeat {
    let response = converter.getLastString(strMax: strMax, strMin: strMin, value: initial)
    if response.isSuccess {
        initial = response.nextVal
        arrPossibilities.append(initial)
    }
} while initial != "ZZZZ"
debugPrint(time1.timeIntervalSinceNow)
debugPrint(arrPossibilities, arrPossibilities.count)
